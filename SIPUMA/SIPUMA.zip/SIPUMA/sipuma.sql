-- Buat database SIPUMA jika belum ada
CREATE DATABASE
IF NOT EXISTS sipuma;
USE sipuma;

-- ==============================
-- TABEL USERS (User & Admin)
-- ==============================
CREATE TABLE users
(
  id INT
  AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR
  (50) NOT NULL UNIQUE,
  password VARCHAR
  (255) NOT NULL,
  nama_lengkap VARCHAR
  (100),
  email VARCHAR
  (100),
  foto VARCHAR
  (255) DEFAULT 'img/avatardefault_92824.png',
  role ENUM
  ('admin', 'user') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

  -- Tambahkan akun admin default
  INSERT INTO users
    (username, password, nama_lengkap, role)
  VALUES
    ('admin', SHA2('admin123', 256), 'Administrator SIPUMA', 'admin');

  -- ==============================
  -- TABEL KATEGORI UMKM
  -- ==============================
  CREATE TABLE kategori_umkm
  (
    id INT
    AUTO_INCREMENT PRIMARY KEY,
  nama_kategori ENUM
    ('Subsisten', 'Potensial', 'Digital', 'Ekspor') NOT NULL,
  deskripsi TEXT
);

    -- Data awal kategori UMKM
    INSERT INTO kategori_umkm
      (nama_kategori, deskripsi)
    VALUES
      ('Subsisten', 'UMKM kecil dengan aset dan omzet rendah'),
      ('Potensial', 'UMKM dengan potensi berkembang'),
      ('Digital', 'UMKM yang terhubung dengan platform digital'),
      ('Ekspor', 'UMKM siap ekspor');

    -- ==============================
    -- TABEL FORMULIR UMKM
    -- ==============================
    CREATE TABLE umkm_form
    (
      id INT
      AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  
  -- Data Pribadi
  nama_lengkap VARCHAR
      (100),
  nik VARCHAR
      (20),
  gender ENUM
      ('Laki-laki', 'Perempuan'),
  tanggal_lahir DATE,
  status_perkawinan VARCHAR
      (20),
  pendidikan VARCHAR
      (10),
  alamat_domisili TEXT,
  no_hp VARCHAR
      (20),
  disabilitas ENUM
      ('Ya', 'Tidak'),
  perempuan_tpk ENUM
      ('Ya', 'Tidak'),
  kepala_keluarga ENUM
      ('Ya', 'Tidak'),

  -- Data Keluarga
  jumlah_anggota_keluarga INT,
  jumlah_tanggungan INT,
  tulang_punggung ENUM
      ('Ya', 'Tidak'),

  -- Data Usaha
  nama_usaha VARCHAR
      (100),
  tahun_mulai VARCHAR
      (10),
  jenis_usaha VARCHAR
      (50),
  bidang_usaha VARCHAR
      (100),
  jumlah_pegawai INT,
  kapasitas_produksi INT,
  omzet INT,
  modal_awal INT,
  target_pasar TEXT,
  legalitas TEXT,
  nib VARCHAR
      (50),
  haki ENUM
      ('Ya', 'Tidak'),
  pencatatan TEXT,
  saluran_digital TEXT,
  pembayaran TEXT,
  status_produksi ENUM
      ('Produksi Sendiri', 'Reseller/Dropship'),
  tempat_usaha VARCHAR
      (50),
  sumber_modal VARCHAR
      (50),
  ikut_pelatihan ENUM
      ('Ya', 'Tidak'),
  butuh_pelatihan ENUM
      ('Ya', 'Tidak'),
  jenis_pelatihan TEXT,
  hambatan_usaha TEXT,
  foto_usaha VARCHAR
      (255),

  kategori_id INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  -- Relasi
  FOREIGN KEY
      (user_id) REFERENCES users
      (id) ON
      DELETE CASCADE,
  FOREIGN KEY (kategori_id)
      REFERENCES kategori_umkm
      (id) ON
      DELETE
      SET NULL
      );

      -- ==============================
      -- TABEL LOG AKTIVITAS
      -- ==============================
      CREATE TABLE log_aktivitas
      (
        id INT
        AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  aktivitas TEXT,
  waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY
        (user_id) REFERENCES users
        (id) ON
        DELETE CASCADE
);
